
 fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,ripple&vs_currencies=usd')
 .then(response => response.json())
 .then(data => {

     const bitcoinPrice = data.bitcoin.usd;
     const ethereumPrice = data.ethereum.usd;
     const ripplePrice = data.ripple.usd;


     const ctx = document.getElementById('cryptoPieChart').getContext('2d');
     new Chart(ctx, {
         type: 'pie',
         data: {
             labels: ['Bitcoin', 'Ethereum', 'Ripple'],
             datasets: [{
                 label: 'Price (USD)',
                 data: [bitcoinPrice, ethereumPrice, ripplePrice],
                 backgroundColor: [
                     'rgba(255, 99, 132, 0.5)',
                     'rgba(54, 162, 235, 0.5)',
                     'rgba(255, 206, 86, 0.5)'
                 ],
                 borderWidth: 1
             }]
         },
         options: {
             responsive: false,
             maintainAspectRatio: false
         }
     });
 })
 .catch(error => console.error('Error fetching cryptocurrency prices:', error));