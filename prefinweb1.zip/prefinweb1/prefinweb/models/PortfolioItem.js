
const mongoose = require('mongoose');

const Schema = mongoose.Schema;


const portfolioItemSchema = new Schema({
    name: String,
    description: String,
    images: [String],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

const PortfolioItem = mongoose.model('PortfolioItem', portfolioItemSchema);

module.exports = PortfolioItem;
