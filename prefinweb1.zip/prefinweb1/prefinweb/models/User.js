
const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const userSchema = new Schema({
    username: String,
    password: String,
    firstName: String,
    lastName: String,
    age: Number,
    country: String,
    gender: String,
    loginAttempts: { type: Number, default: 0 }
});


const User = mongoose.model('User', userSchema);

module.exports = User;
