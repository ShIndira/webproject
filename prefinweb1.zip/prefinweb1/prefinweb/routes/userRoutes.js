const express = require('express');
const router = express.Router();
const UserController = require('../controllers/UserController');

router.get('/', UserController.getIndex);
router.get('/register', UserController.getRegister);
router.post('/register', UserController.postRegister);
router.get('/login', UserController.getLogin);
router.post('/login', UserController.postLogin);
router.get('/reset-password', UserController.getResetPassword);
router.post('/reset-password', UserController.postResetPassword);
router.get('/dashboard', UserController.getDashboard);
router.get('/logout', UserController.logout);

module.exports = router;

