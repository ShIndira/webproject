const express = require('express');
const router = express.Router();
const multer = require('multer');
const AdminController = require('../controllers/AdminController');


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage: storage });

// Define routes for the admin interface
router.get('/', AdminController.getAdminDashboard);
router.get('/add', AdminController.getAddPortfolioItem);
router.post('/add', upload.array('images', 3), AdminController.postAddPortfolioItem);
router.post('/delete/:id', AdminController.deletePortfolioItem);
router.get('/edit/:id', AdminController.getEditPortfolioItem);
router.post('/edit/:id', upload.array('images', 3), AdminController.postEditPortfolioItem);

module.exports = router;
