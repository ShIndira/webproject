
const { app, PORT } = require('./server');

const routes = require('./routes');

app.use(routes);

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});