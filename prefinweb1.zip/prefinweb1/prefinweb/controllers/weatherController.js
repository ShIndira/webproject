// weatherController.js
// Import necessary module for making HTTP requests
const axios = require('axios');

// Define weatherController object to handle weather-related operations
const weatherController = {
    // Method to fetch weather data for multiple cities
    getWeather: async (req, res) => {
        try {
            // API key for accessing weather data
            const apiKey = 'f266a8ce0688d7b07812c06e85eae759'; // Replace with your weather API key
            // List of cities for which weather data will be fetched
            const cities = ['Astana', 'Almaty', 'Nur-Sultan'];
            const weatherDataArray = []; // Array to store weather data for each city

            // Iterate over each city and fetch its weather data
            for (const city of cities) {
                // Construct the API URL for the current city
                const apiUrl = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;
                // Make a GET request to the OpenWeatherMap API
                const response = await axios.get(apiUrl);
                // Extract weather data from the response
                const weatherData = response.data;
                // Push city name and temperature data to the weatherDataArray
                weatherDataArray.push({ city: city, temperature: weatherData.main.temp });
            }

            // Send the weather data array as a JSON response
            res.json(weatherDataArray);
        } catch (error) {
            // Handle errors in fetching weather data
            console.error('Error fetching weather data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
};

module.exports = weatherController; // Export the weatherController object for use in other modules
