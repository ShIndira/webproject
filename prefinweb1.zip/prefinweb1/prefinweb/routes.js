const express = require('express');
const app = express();

const userRoutes = require('./routes/userRoutes');
const adminRoutes = require('./routes/adminRoutes');
const weatherController = require('./controllers/weatherController');

app.use('/', userRoutes);
app.use('/admin', adminRoutes);
app.get('/api/weather', weatherController.getWeather);

module.exports = app;
